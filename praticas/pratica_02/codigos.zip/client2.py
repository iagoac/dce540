# -*- coding: UTF-8 -*-

import rpyc
import sys
from PIL import Image

if (len(sys.argv) != 4):
    print("uso: ",sys.argv[0]," <IP do servidor> <porta do servidor> <palavra>")
c = rpyc.connect(sys.argv[1], sys.argv[2])
pic=c.root.picture(sys.argv[3])

