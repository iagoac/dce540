# -*- coding: UTF-8 -*-

import rpyc
import sys

if (len(sys.argv) != 4):
    print("uso: ",sys.argv[0]," <IP do servidor> <porta do servidor> <palavra>")
c = rpyc.connect(sys.argv[1], sys.argv[2])
print(c.root.reply(sys.argv[3]))

