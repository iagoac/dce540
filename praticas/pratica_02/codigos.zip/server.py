# -*- coding: UTF-8 -*-
import rpyc
import sys
from PIL import Image

class Servidor_dialogo(rpyc.Service):
    #Gancho: executa no início de cada conexão.
    def on_connect(self, conn):
        pass
    
    #Gancho: executa no fim de cada conexão.
    def on_disconnect(self, conn):
        pass
    
    #Rotina exposta: pode ser acessada pelo cliente RPC
    def exposed_reply(self, hisname):
        print("olá, ", hisname)
        return "olá, " + hisname
    
    #Rotina exposta
    def exposed_picture(self, code):
        subdir="pics/"
        #alias para notação curta
        s=subdir
        filenames={
                "necoarc": s+"neco-arc.png",
                "peepo": s+"peepo-toys.jpg",
                "gato": s+"soyjack.png",
                "soyjack": s+"cat.jpg",
                "maguary": s+"maguary.jpg"}
        print("picture selected: ", filenames[code])
        output=Image.open(filenames[code])
        output.show()
        return output

#Inicialização do servidor RPC
if __name__ == "__main__":
    from rpyc.utils.server import ThreadedServer
    t = ThreadedServer(Servidor_dialogo, port=sys.argv[1])
    t.start()
