#!/bin/bash
watch-md () { for (( ;; )) ; do inotifywait -e modify doc.md; md2html doc.md -o doc.html ; sleep .7; done }

qutebrowser doc.html &
watch-md
